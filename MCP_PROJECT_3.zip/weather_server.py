from mcp.server.fastmcp import FastMCP
from dotenv import load_dotenv
from langchain_community.tools import OpenWeatherMapQueryRun
from langchain_community.utilities import OpenWeatherMapAPIWrapper
from langchain_community.tools.openweathermap import OpenWeatherMapQueryRun
load_dotenv()

# Initialize MCP server
mcp = FastMCP(
    "weather",
    host="127.0.0.1",
    port=8003
)

# Initialize Weather API wrapper
weather_api_wrapper = OpenWeatherMapAPIWrapper()

# Initialize LangChain Weather tool
weather = OpenWeatherMapQueryRun(
    api_wrapper=weather_api_wrapper,
    description="Get current weather information for a given location"
)

# MCP wrapper function
@mcp.tool()
def get_weather(location: str) -> str:
    """
    Get current weather information for the specified city.
    Example: Surat, India
    """
    try:
        result = weather.run(location)
        return result

    except Exception as e:
        return f"Error fetching weather: {str(e)}"


if __name__ == "__main__":
    mcp.run(transport="streamable-http")