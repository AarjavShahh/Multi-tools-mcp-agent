def main() -> None:
    print("Hello from mcp-project-3!")
