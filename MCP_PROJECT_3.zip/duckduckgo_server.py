from mcp.server.fastmcp import FastMCP
from langchain_community.tools import DuckDuckGoSearchRun
from langchain_community.utilities import DuckDuckGoSearchAPIWrapper

mcp = FastMCP("duckduckgo")

duckduckgo_api_wrapper = DuckDuckGoSearchAPIWrapper()

search = DuckDuckGoSearchRun(
    api_wrapper=duckduckgo_api_wrapper,
    description="Search the internet using DuckDuckGo and return relevant web results."
)

@mcp.tool()
def search_duckduckgo(query: str) -> str:
    """Search the web using DuckDuckGo."""
    try:
        return search.run(query)
    except Exception as e:
        return f"Error searching DuckDuckGo: {str(e)}"


if __name__ == "__main__":
    mcp.run(transport="stdio")
