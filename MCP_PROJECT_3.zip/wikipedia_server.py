from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper
from mcp.server.fastmcp import FastMCP

# Initialize MCP server
mcp = FastMCP("wiki")

# Initialize Wikipedia API wrapper
wiki_api_wrapper = WikipediaAPIWrapper(
    top_k_results=2,
    doc_content_chars_max=500
)

# Initialize LangChain Wikipedia tool
wiki = WikipediaQueryRun(
    api_wrapper=wiki_api_wrapper,
    description="Search Wikipedia for information about people, places, concepts and events."
)

# MCP wrapper function
@mcp.tool()
def search_wikipedia(query: str) -> str:
    """
    Search Wikipedia and return relevant information.
    """
    try:
        result = wiki.run(query)
        return result

    except Exception as e:
        return f"Error searching Wikipedia: {str(e)}"


if __name__ == "__main__":
    mcp.run(transport="stdio")
