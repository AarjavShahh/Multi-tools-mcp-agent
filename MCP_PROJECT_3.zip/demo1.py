import asyncio
import os
import sys
from pathlib import Path
from typing import Annotated
from langgraph.checkpoint import memory
from typing_extensions import TypedDict

from dotenv import load_dotenv

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_groq import ChatGroq
from langchain_core.messages import BaseMessage, SystemMessage, HumanMessage

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition

from langgraph.checkpoint.memory import MemorySaver
memory = MemorySaver()

BASE_DIR = Path(__file__).resolve().parent

# Load environment variables
load_dotenv(BASE_DIR / ".env")

# LangSmith configuration (optional)
# langsmith_key = os.getenv("LANGCHAIN_API_KEY")

# if langsmith_key:
#     os.environ["LANGSMITH_API_KEY"] = langsmith_key
#     os.environ["LANGSMITH_TRACING"] = "true"

os.environ["LANGSMITH_TRACING"] = "true"
os.environ["LANGSMITH_PROJECT"] = "MCP_PROJECT_3"

if not os.getenv("LANGSMITH_API_KEY"):
    raise ValueError("LANGSMITH_API_KEY is missing from .env")


print("LangSmith tracing:", os.getenv("LANGSMITH_TRACING"))
print("LangSmith project:", os.getenv("LANGSMITH_PROJECT"))

# Check Groq API key
if not os.getenv("GROQ_API_KEY"):
    raise ValueError("GROQ_API_KEY is missing from .env")




async def main():

    # 1. Initialize MCP clients
    client = MultiServerMCPClient(
        {
            "weather": {
                "url": "http://127.0.0.1:8003/mcp",
                "transport": "streamable_http",
            },

            "tavily": {
                "url": "http://127.0.0.1:8004/mcp",
                "transport": "streamable_http",
            },

            "wiki": {
                "transport": "stdio",
                "command": sys.executable,
                "args": [str(BASE_DIR / "wikipedia_server.py")]
            },

            "arxiv": {
                "transport": "stdio",
                "command": sys.executable,
                "args": [str(BASE_DIR / "arxiv_server.py")]
            },

            "duckduckgo": {
                "transport": "stdio",
                "command": sys.executable,
                "args": [str(BASE_DIR / "duckduckgo_server.py")]
            }
        }
    )

    # 2. Retrieve MCP tools
    tools = await client.get_tools()

    print("\nAvailable MCP Tools:")

    for t in tools:
        print(t.name)
        # print("Arguments:", t.args)

    # 3. Initialize Groq model
    model = ChatGroq(
        model="qwen/qwen3.8-27b",
        temperature=0
    )

    # 4. Bind MCP tools to the model
    llm_with_tools = model.bind_tools(tools)

    # 5. Define State
    class State(TypedDict):
        messages: Annotated[list[BaseMessage], add_messages]

    # 6. System prompt
    system_prompt = """
    You are an AI assistant with access to MCP tools.

    Instructions:
    1. Use weather tools for weather-related queries.
    2. Use Tavily for current information and web searches.
    3. Use Wikipedia for general knowledge.
    4. Use Arxiv for scientific research papers.
    5. Use DuckDuckGo for internet searches.
    6. Only call tools that are available.
    7. Provide clear and accurate answers.
    """

    # 7. Define LLM node
    async def call_llm_model(state: State):
        response = await llm_with_tools.ainvoke(state["messages"])
        return {"messages": [response]}

    # 8. Initialize StateGraph
    builder = StateGraph(State)

    # 9. Add nodes
    builder.add_node("llm", call_llm_model)
    builder.add_node("tools", ToolNode(tools))

    # 10. Add edges
    builder.add_edge(START, "llm")

    builder.add_conditional_edges(
        "llm",
        tools_condition
    )

    builder.add_edge("tools", "llm")

    # 11. Compile graph
    graph = builder.compile(checkpointer=memory)

    print("\nStateGraph compiled successfully!")

    # Optional: Display graph structure in terminal
    print(graph.get_graph().draw_mermaid())

   # Keep the same thread ID throughout the conversation
    config = {
        "configurable": {
            "thread_id": "1"
        }
    }

    first_message = True

    while True:

        x = input("\nYou: ")

        if x.lower() in ["exit", "quit", "bye"]:
            print("Chatbot stopped.")
            break

        # Add system prompt only on the first interaction
        if first_message:
            messages = [
                SystemMessage(content=system_prompt),
                HumanMessage(content=x)
            ]
            first_message = False

        else:
            messages = [
                HumanMessage(content=x)
            ]

        response = await graph.ainvoke(
            {"messages": messages},
            config=config
        )

        print("\nAssistant:")
        print(response["messages"][-1].content)


if __name__ == "__main__":
    asyncio.run(main())
