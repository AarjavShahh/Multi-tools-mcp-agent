
from mcp.server.fastmcp import FastMCP
from dotenv import load_dotenv
from langchain_community.tools.tavily_search import TavilySearchResults

load_dotenv()

# Initialize MCP server
mcp = FastMCP(
    "tavily",
    host="127.0.0.1",
    port=8004
)

# Initialize LangChain Tavily tool
tavily_server = TavilySearchResults(
    max_results=5,
    description="Search the web for current and relevant information"
)

# MCP wrapper function
@mcp.tool()
def search_web(query: str) -> str:
    """
    Search the web using Tavily and return relevant results.
    """
    try:
        result = tavily_server.invoke({"query": query})
        return str(result)

    except Exception as e:
        return f"Error searching the web: {str(e)}"


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
