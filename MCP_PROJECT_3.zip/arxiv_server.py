from langchain_community.tools import ArxivQueryRun
from langchain_community.utilities import ArxivAPIWrapper
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("arxiv")

arxiv_api_wrapper = ArxivAPIWrapper(
    top_k_results=2,
    doc_content_chars_max=1000
)

arxiv = ArxivQueryRun(
    api_wrapper=arxiv_api_wrapper,
    description="Search arXiv for research papers on AI, machine learning, deep learning, and other scientific topics."
)

@mcp.tool()
def search_arxiv(query: str) -> str:
    """Search arXiv research papers using a given query."""
    try:
        return arxiv.run(query)
    except Exception as e:
        return f"Error searching arXiv: {str(e)}"


if __name__ == "__main__":
    mcp.run(transport="stdio")
